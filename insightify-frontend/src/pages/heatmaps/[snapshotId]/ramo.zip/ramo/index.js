import Head from "next/head";
import style from "./style.module.css";
import { useCallback, useEffect, useState } from "react";
import Emptydataview from "../../../components/emptydataview";
import { useRouter } from "next/router";
import HeatmapList from "@/components/Heatmap/HeatmapList";
import PagesHeader from "../../../components/pagesHeader";
import Loading from "../../../components/loading";
import AddNewHeatmap from "../../../components/addNewHeatmap/container";
import HeatmapAside from "../../../components/heatmapAside"
import LastDayAddFilter from "../../../components/lastDayAddFilter/lastDayAddFilterContainer"
import SnapshotContainer from "../../../components/snapshot/snapshotContainer"

export const addNewHtmpBtnProps = {
  padding: "6px 14px",
  btncolor: "inherit",
  btncolorHover: "#f0f0f0",
  text: "Saved",
  textColor: "#707070",
  textColorHover: "#2c2c2c",
  borderRadius: "6px",
  border: "none",
};

export const shareBtnProps = {
  padding: "6px 12px",
  btncolor: "inherit",
  btncolorHover: "#2e8def",
  text: "Share",
  textColor: "#2e8def",
  textColorHover: "#fff",
  borderRadius: "6px",
  border: "1px solid #2e8def",
};

export default function Test() {
  const [isLoading, setLoading] = useState(true);
  const [verified, setVerified] = useState(false);
  const router = useRouter();

  useEffect(() => {
    try {
      fetch("/api/code/verify?ro=1")
        .then((result) => result.json())
        .then(({ verified }) => {
          setVerified((state) => verified);
        })
        .finally(() => {
          setLoading((state) => false);
        });
    } catch (err) {}
  }, []);

  const installCodeClick = useCallback(() => {
    router.push("/overview");
  }, [router]);

  let content = null;

  content = (
    <>
      <HeatmapAside />
      <div className={style.contentWrapper}>
        <header className={style.header}>
        <PagesHeader
          shareButtonProps={...shareBtnProps}
          savedButtonProps={...addNewHtmpBtnProps}
          title={"Usersnap"}
          url={"https://usersnap.com/"}
        />
        <LastDayAddFilter />
        </header>
        <main className={style.snapshotWrapper}>
          <SnapshotContainer />
        </main>
      </div>
    </>
  );

  return (
    <>
      <Head>
        <meta charSet="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Heatmap</title>
      </Head>

      <div className={style.container}>{content}</div>
    </>
  );
}